package controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import connections.DBConnection;
import interfaces.TeacherDao;
import models.Course;
import models.Teacher;

public class TeacherController implements TeacherDao {

	@Override
	public int addTeacher(Teacher teacher) {

		int saved =0;
    	try {
    	 Connection con = new DBConnection().getConnection("root", "root");	
    			 String Query = "Insert into Teacher (fname, lname, qualification, phone_number, salary, email, password) values (?,?,?,?,?,?,?)";
         
        PreparedStatement preparedStatement = con.prepareStatement(Query);
    	preparedStatement.setString(1, teacher.getfName());
    	preparedStatement.setString(2, teacher.getlName());
    	preparedStatement.setString(3, teacher.getQualification());
    	preparedStatement.setString(4, teacher.getPhoneNumber());
    	preparedStatement.setInt(5, teacher.getSalary());
    	preparedStatement.setString(6, teacher.getEmail());
    	preparedStatement.setString(7, teacher.getPassword());
    	
    	saved = preparedStatement.executeUpdate();
    	
    	}catch (Exception e) {
		
    		e.printStackTrace();
    	}
        return saved;
	}

	@Override
	public List<Teacher> getAllTeachers() {
		List<Teacher> teachers = new ArrayList<Teacher>();
		try {
	    	 Connection con = new DBConnection().getConnection("root", "root");	
	    			 String Query = "select * from Teacher";
	         
	        PreparedStatement preparedStatement = con.prepareStatement(Query);
	    	ResultSet rs = preparedStatement.executeQuery();
	    	while(rs.next()) {
	    	
	    		Teacher teacher = new Teacher(rs.getString("fname"), rs.getString("lname"), rs.getString("qualification"), rs.getString("phone_number"), rs.getInt("salary"), rs.getString("email"), rs.getString("password"));
	    		teacher.setTssn(rs.getInt("tssn"));
	    		teachers.add(teacher);
	    		
	    	}
	    	
	    	}catch (Exception e) {
			
	    		e.printStackTrace();
	    	}
	
		return teachers;
	}

	@Override
	public int deleteTeacher(int id) {
		int deleted =0;
    	try {
    	 Connection con = new DBConnection().getConnection("root", "root");	
    			 String Query = "delete from teacher where tssn = ?";
         
        PreparedStatement preparedStatement = con.prepareStatement(Query);
    	preparedStatement.setInt(1, id);
    	deleted = preparedStatement.executeUpdate();
    	
    	}catch (Exception e) {
		
    		e.printStackTrace();
    	}
        return deleted;

	}

	@Override
	public int AddTeacherCourse(int courseCode, int tssn) {

		int saved =0;
    	try {
    	 Connection con = new DBConnection().getConnection("root", "root");	
    			 String Query = "Insert into Course_has_Teacher (Course_code, Teacher_tssn) values (?,?)";
         
        PreparedStatement preparedStatement = con.prepareStatement(Query);
    	preparedStatement.setInt(1, courseCode);
    	preparedStatement.setInt(2, tssn);
    	
    	saved = preparedStatement.executeUpdate();
    	
    	}catch (Exception e) {
		
    		e.printStackTrace();
    	}
        return saved;

	}

	@Override
	public List<String[]> getAllAssignCourses() {
		List<String[]> courses = new ArrayList<>();
		try {
	    	 Connection con = new DBConnection().getConnection("root", "root");	
	    			 String Query = "select t.fname, t.lname , c.cname from Course_has_Teacher ct, Teacher t, Course c Where c.code = ct.Course_code AND t.tssn = ct.Teacher_tssn";
	         
	        PreparedStatement preparedStatement = con.prepareStatement(Query);
	    	ResultSet rs = preparedStatement.executeQuery();
	    	while(rs.next()) {
	    	
	    		String name = rs.getString("fname")+" "+rs.getString("lname");
	    		String[] c = new String[] {name, rs.getString("cname")};
	    		courses.add(c);
	    		
	    	}
	    	
	    	}catch (Exception e) {
			
	    		e.printStackTrace();
	    	}
	
		return courses;

	}
	
	@Override
	public int login(String email, String password) {
		
		int loggedIn =0;
		try {
	    	 Connection con = new DBConnection().getConnection("root", "root");	
	    			 String Query = "Select fname , lname From Teacher WHERE email =? AND password = ?";
	         
	        PreparedStatement preparedStatement = con.prepareStatement(Query);
	        preparedStatement.setString(1, email);
	        preparedStatement.setString(2, password);
	        
	    	ResultSet rs = preparedStatement.executeQuery();
	    	while(rs.next()) {
	    
	    		loggedIn = 1;
	    		
	    	}
	    	
	    	}catch (Exception e) {
			
	    		e.printStackTrace();
	    	}
	
		return loggedIn;
		
	}


}
