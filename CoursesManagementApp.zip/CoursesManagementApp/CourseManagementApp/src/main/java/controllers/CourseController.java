package controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import connections.DBConnection;
import interfaces.CourseDao;
import models.Course;

public class CourseController implements CourseDao {

	@Override
	public int addCourse(Course course) {

		int saved =0;
    	try {
    	 Connection con = new DBConnection().getConnection("root", "root");	
    			 String Query = "Insert into course (code, ctitle, cname, hours) values (?,?,?,?)";
         
        PreparedStatement preparedStatement = con.prepareStatement(Query);
    	preparedStatement.setInt(1, course.getCourseCode());
    	preparedStatement.setString(2, course.getCourseTitle());
    	preparedStatement.setString(3, course.getCourseName());
    	preparedStatement.setInt(4, course.getCreditHours());
    	
    	saved = preparedStatement.executeUpdate();
    	
    	}catch (Exception e) {
		
    		e.printStackTrace();
    	}
        return saved;
	}

	@Override
	public List<Course> getAllCourses() {
		
		List<Course> courses = new ArrayList<Course>();
		try {
	    	 Connection con = new DBConnection().getConnection("root", "root");	
	    			 String Query = "select * from Course";
	         
	        PreparedStatement preparedStatement = con.prepareStatement(Query);
	    	ResultSet rs = preparedStatement.executeQuery();
	    	while(rs.next()) {
	    	
	    		Course course = new Course(rs.getInt("code"), rs.getString("ctitle"), rs.getString("cname"), rs.getInt("hours"));
	    		courses.add(course);
	    		
	    	}
	    	
	    	}catch (Exception e) {
			
	    		e.printStackTrace();
	    	}
	
		return courses;
	}

	@Override
	public int deleteCourse(int courseCode) {
		int deleted =0;
    	try {
    	 Connection con = new DBConnection().getConnection("root", "root");	
    			 String Query = "delete from course where code = ?";
         
        PreparedStatement preparedStatement = con.prepareStatement(Query);
    	preparedStatement.setInt(1, courseCode);
    	deleted = preparedStatement.executeUpdate();
    	
    	}catch (Exception e) {
		
    		e.printStackTrace();
    	}
        return deleted;

	}

}
