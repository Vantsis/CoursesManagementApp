package controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import connections.DBConnection;
import interfaces.StudentDao;
import models.Student;
import models.Teacher;

public class StudentController implements StudentDao {

	@Override
	public int save(Student student) {
	
		int saved =0;
    	try {
    	 Connection con = new DBConnection().getConnection("root", "root");	
    			 String Query = "Insert into student (fname, lname, email, section, age, mobileno, password) values (?,?,?,?,?,?,?)";
         
        PreparedStatement preparedStatement = con.prepareStatement(Query);
    	preparedStatement.setString(1, student.getFirstName());
    	preparedStatement.setString(2, student.getLastName());
    	preparedStatement.setString(3, student.getEmail());
    	preparedStatement.setString(4, student.getSection());
    	preparedStatement.setInt(5, student.getAge());
    	preparedStatement.setString(6, student.getMobileNo());
    	preparedStatement.setString(7, student.getPasswod());
    	
    	saved = preparedStatement.executeUpdate();
    	
    	}catch (Exception e) {
		
    		e.printStackTrace();
    	}
        return saved;
	}

	@Override
	public List<Student> getAllStudents() {
		List<Student> students = new ArrayList<Student>();
		try {
	    	 Connection con = new DBConnection().getConnection("root", "root");	
	    			 String Query = "select * from Student";
	         
	        PreparedStatement preparedStatement = con.prepareStatement(Query);
	    	ResultSet rs = preparedStatement.executeQuery();
	    	while(rs.next()) {
	    	
	    		Student student = new Student(rs.getInt("id"),rs.getString("fname"), rs.getString("lname"), rs.getString("section"), rs.getInt("age"), rs.getString("mobileNo"), rs.getString("email"), rs.getString("password"));
	    		students.add(student);
	    		
	    	}
	    	
	    	}catch (Exception e) {
			
	    		e.printStackTrace();
	    	}
	
		return students;
	}
	@Override
	public int AddStudentCourse(int courseCode, int studenId) {

		int saved =0;
    	try {
    	 Connection con = new DBConnection().getConnection("root", "root");	
    			 String Query = "Insert into Student_has_Course (Course_code, Student_id) values (?,?)";
         
        PreparedStatement preparedStatement = con.prepareStatement(Query);
    	preparedStatement.setInt(1, courseCode);
    	preparedStatement.setInt(2, studenId);
    	
    	saved = preparedStatement.executeUpdate();
    	
    	}catch (Exception e) {
		
    		e.printStackTrace();
    	}
        return saved;

	}

	
	@Override
	public List<String[]> getAllAssignCourses() {
		List<String[]> courses = new ArrayList<>();
		try {
	    	 Connection con = new DBConnection().getConnection("root", "root");	
	    			 String Query = "select t.fname, t.lname , c.cname from Student_has_Course ct, Student t, Course c Where c.code = ct.Course_code AND t.id = ct.Student_id";
	         
	        PreparedStatement preparedStatement = con.prepareStatement(Query);
	    	ResultSet rs = preparedStatement.executeQuery();
	    	while(rs.next()) {
	    	
	    		String name = rs.getString("fname")+" "+rs.getString("lname");
	    		String[] c = new String[] {name, rs.getString("cname")};
	    		courses.add(c);
	    		
	    	}
	    	
	    	}catch (Exception e) {
			
	    		e.printStackTrace();
	    	}
	
		return courses;

	}
	
	@Override
	public int login(String email, String password) {
		
		int loggedIn =0;
		try {
	    	 Connection con = new DBConnection().getConnection("root", "root");	
	    			 String Query = "Select fname , lname From Student WHERE email =? AND password = ?";
	         
	        PreparedStatement preparedStatement = con.prepareStatement(Query);
	        preparedStatement.setString(1, email);
	        preparedStatement.setString(2, password);
	        
	    	ResultSet rs = preparedStatement.executeQuery();
	    	while(rs.next()) {
	    
	    		loggedIn = 1;
	    		
	    	}
	    	
	    	}catch (Exception e) {
			
	    		e.printStackTrace();
	    	}
	
		return loggedIn;
		
	}
		
}
