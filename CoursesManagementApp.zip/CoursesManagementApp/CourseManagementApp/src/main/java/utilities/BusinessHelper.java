package utilities;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connections.DBConnection;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BusinessHelper {
    /**
     * check if name is valid
     *
     * @param name the name user provides
     * @return valid or not valid
     */
    public static boolean validName(String name) {
        return Constant.namePattern.matcher(name).matches();
    }

    /**
     * check if email is valid
     *
     * @param email the email user provides
     * @return valid or not valid
     */
    public static boolean isValidEmail(String email) {
        if (email == null) {
            return false;
        }
        return Constant.emailPattern.matcher(email).matches();
    }
    
    /**
     * Get username with the email and password
     *
     * @param email
     * @param password
     * @return userName
     * @throws SQLException
     */
    public static String getUserName(String email, String password) throws SQLException {
    	
    	String username = null;
    	try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
             Connection con=DriverManager.getConnection(  
             		"jdbc:mysql://localhost:3306/restaurants",Constant.DBUserName, Constant.DBPassword);  
             String Query = "Select name from user where email =? AND password =?";
             
            PreparedStatement preparedStatement = con.prepareStatement(Query);
        	preparedStatement.setString(1, email);
        	preparedStatement.setString(2, password);
        	ResultSet rs  = preparedStatement.executeQuery();
        	while(rs.next()) {
        		
        		username = rs.getString("name");
        		
        	}
        	}catch (Exception e) {
    		
        		e.printStackTrace();
        	}

        return username;
    }

    /**
     * Get userID with email
     *
     * @param email
     * @return userID
     * @throws SQLException
     */
    public static int getUserID(String email) throws SQLException {
    
    	int user_id = 0;
    	
    	try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
             Connection con=DriverManager.getConnection(  
             		"jdbc:mysql://localhost:3306/restaurants",Constant.DBUserName, Constant.DBPassword);  
             String Query = "Select user_id from user where email =?";
             
            PreparedStatement preparedStatement = con.prepareStatement(Query);
        	preparedStatement.setString(1, email);
        	ResultSet rs  = preparedStatement.executeQuery();
        	while(rs.next()) {
        		
        		user_id = rs.getInt("user_id");
        		
        	}
        	}catch (Exception e) {
    		
        		e.printStackTrace();
        	}

        return user_id;
    }

    /**
     * check if the email and password matches
     *
     * @param email
     * @param password
     */
    public static boolean checkPassword(String email, String password) throws SQLException {

    	boolean check = false;
    	
    	try {
        	Class.forName("com.mysql.jdbc.Driver");
             Connection con=DriverManager.getConnection(  
             		"jdbc:mysql://localhost:3306/restaurants",Constant.DBUserName, Constant.DBPassword);  
             String Query = "Select user_id from user where email =? AND password = ?";
             
            PreparedStatement preparedStatement = con.prepareStatement(Query);
        	preparedStatement.setString(1, email);
        	preparedStatement.setString(2, password);
        	
        	ResultSet rs  = preparedStatement.executeQuery();
        	while(rs.next()) {
        		
        		check  = true;
        		
        	}
        	}catch (Exception e) {
    		
        		e.printStackTrace();
        	}

        return check;
    }

    /**
     * Check if email is already registered
     *
     * @param email
     * @param request
     * @param response
     * @return email registered or not
     * @throws ServletException
     * @throws IOException
     */
    public static boolean emailAlreadyRegistered(String email, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	boolean check = false;
    	
    	try {
        	 Connection con= new DBConnection().getConnection("root", "root"); 
        
        	 String Query = "Select id from student where email =?";
             
            PreparedStatement preparedStatement = con.prepareStatement(Query);
        	preparedStatement.setString(1, email);
        	
        	ResultSet rs  = preparedStatement.executeQuery();
        	while(rs.next()) {
        		
        		check  = true;
        		
        	}
        	}catch (Exception e) {
    		
        		e.printStackTrace();
        	}

        return check;

    }
}
