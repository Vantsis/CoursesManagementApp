package interfaces;


import java.util.List;

import models.Course;

public interface CourseDao {

	public int addCourse(Course course);
	public List<Course> getAllCourses();
	public int deleteCourse(int courseCode);

}
