package interfaces;

import java.util.List;

import models.Student;

public interface StudentDao {

	public int save(Student student);
	public int login(String email, String password);
	public List<Student> getAllStudents();
	public List<String[]> getAllAssignCourses();
	public int AddStudentCourse(int courseCode, int studenId);

}
