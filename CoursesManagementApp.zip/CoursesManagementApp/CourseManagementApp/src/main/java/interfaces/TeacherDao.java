package interfaces;

import java.util.List;

import models.Course;
import models.Teacher;

public interface TeacherDao {

	public int addTeacher(Teacher teacher);
	public List<Teacher> getAllTeachers();
	public int deleteTeacher(int id);
	public int AddTeacherCourse(int courseCode, int tssn);
	public List<String[]> getAllAssignCourses();
	public int login(String email, String password);
		
	
	
}
