package models;

public class Course {

	private int courseCode;
	private String courseTitle;
	private String courseName;
	private int creditHours;
	
	public Course(int courseCode, String courseTitle, String courseName, int creditHours) {
		super();
		this.courseCode = courseCode;
		this.courseTitle = courseTitle;
		this.courseName = courseName;
		this.creditHours = creditHours;
	}

	public int getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(int courseCode) {
		this.courseCode = courseCode;
	}

	public String getCourseTitle() {
		return courseTitle;
	}

	public void setCourseTitle(String courseTitle) {
		this.courseTitle = courseTitle;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public int getCreditHours() {
		return creditHours;
	}

	public void setCreditHours(int creditHours) {
		this.creditHours = creditHours;
	}
	
	
	
	
	
	
}
