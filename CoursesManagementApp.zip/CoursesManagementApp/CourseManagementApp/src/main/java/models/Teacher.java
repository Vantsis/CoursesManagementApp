package models;

public class Teacher {

	private int  tssn; 
	private String fName;
	private String lName;
	private String qualification;
	private String phoneNumber;
	private int salary;
	private String email;
	private String password;

	public Teacher(String fName, String lName, String qualification, String phoneNumber, int salary,
			String email, String password) {
		super();
		this.fName = fName;
		this.lName = lName;
		this.qualification = qualification;
		this.phoneNumber = phoneNumber;
		this.salary = salary;
		this.email = email;
		this.password = password;
	}

	public int getTssn() {
		return tssn;
	}

	public void setTssn(int tssn) {
		this.tssn = tssn;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	

	
	
	
}
