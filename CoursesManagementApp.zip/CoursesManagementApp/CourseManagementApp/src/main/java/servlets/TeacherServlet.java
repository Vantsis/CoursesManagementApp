package servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controllers.CourseController;
import controllers.StudentController;
import controllers.TeacherController;
import models.Course;
import models.Student;
import models.Teacher;
import utilities.BusinessHelper;


/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/TeacherServlet")
public class TeacherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TeacherServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String Email = request.getParameter("email");
		String Password = request.getParameter("password");
		
		String username = null;
		try {
			username = new BusinessHelper().getUserName(Email, Password);
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(username!=null) {
			
			 HttpSession session = request.getSession();
		     session.setAttribute("username", username);
		 	 response.sendRedirect("home.jsp");
			   
			
		}else {
			
			response.sendRedirect("login.jsp?msg=1");
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String FirstName = request.getParameter("fname");
		String LastName = request.getParameter("lname");
		String Qualification = request.getParameter("qualification");
		String Phone = request.getParameter("phone");
		String Salary = request.getParameter("salary");
		String Email = request.getParameter("email");
		String Password = request.getParameter("password");
		String CPassword = request.getParameter("cpassword");
	
		Teacher teacher = new Teacher(FirstName, LastName, Qualification, Phone, Integer.parseInt(Salary), Email, Password);
		
		boolean ValidEmail = new BusinessHelper().isValidEmail(Email);
		boolean ValidName = new BusinessHelper().validName(FirstName);
		boolean SamePass = Password.equals(CPassword);
		
		if(ValidEmail && ValidName && SamePass)
		{
		
			int register = new TeacherController().addTeacher(teacher);
			if(register>0) {
				
				response.sendRedirect("teachers.jsp?msg=200");
					
			}else {
				
				response.sendRedirect("teachers.jsp?msg=0");
				
			}
			}else {
				
				response.sendRedirect("teachers.jsp?msg=300");
							
			}
		

			
	}

}
