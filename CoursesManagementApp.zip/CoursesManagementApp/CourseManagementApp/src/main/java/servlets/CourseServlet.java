package servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controllers.CourseController;
import controllers.StudentController;
import models.Course;
import models.Student;
import utilities.BusinessHelper;


/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/CourseServlet")
public class CourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CourseServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String Email = request.getParameter("email");
		String Password = request.getParameter("password");
		
		String username = null;
		try {
			username = new BusinessHelper().getUserName(Email, Password);
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(username!=null) {
			
			 HttpSession session = request.getSession();
		     session.setAttribute("username", username);
		 	 response.sendRedirect("home.jsp");
			   
			
		}else {
			
			response.sendRedirect("login.jsp?msg=1");
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String CourseCode = request.getParameter("code");
		String CourseTitle = request.getParameter("title");
		String CourseName = request.getParameter("cname");
		String CreditHours = request.getParameter("chours");
		
		Course course = new Course(Integer.parseInt(CourseCode), CourseTitle, CourseName, Integer.parseInt(CreditHours));
		
		int register = new CourseController().addCourse(course);
		
		if(register>0) {
				
				response.sendRedirect("courses.jsp?msg=200");
					
			}else {
				
				response.sendRedirect("courses.jsp?msg=0");
				
			}
			
	}

}
