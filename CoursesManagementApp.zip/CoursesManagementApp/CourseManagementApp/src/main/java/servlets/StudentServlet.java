package servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controllers.StudentController;
import models.Student;
import utilities.BusinessHelper;


/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String FirstName = request.getParameter("fname");
		String LastName = request.getParameter("lname");
		String Email = request.getParameter("email");
		String Section = request.getParameter("section");
		String Age = request.getParameter("age");
		String MobileNo = request.getParameter("mobileno");
		String Password = request.getParameter("password");
		String CPassword = request.getParameter("cpassword");
		
		Student student = new Student(0, FirstName, LastName, Section, Integer.parseInt(Age), Email, MobileNo, CPassword);
		
		boolean ValidEmail = new BusinessHelper().isValidEmail(Email);
		boolean ValidName = new BusinessHelper().validName(FirstName);
		boolean SamePass = Password.equals(CPassword);
		boolean alreadyEmail = new BusinessHelper().emailAlreadyRegistered(Email, request, response);
		
		if(ValidEmail && ValidName && SamePass)
		{
			if(!alreadyEmail) {
		
			int register = new StudentController().save(student);
			if(register>0) {
				
				response.sendRedirect("login.jsp?msg=200");
					
			}else {
				
				response.sendRedirect("login.jsp?msg=0");
				
			}
			}else {
				
				response.sendRedirect("login.jsp?msg=300");
							
			}
		
			
		}else {
			
			response.sendRedirect("login.jsp?msg=2");
		}
		
		
		
		
			
	}

}
